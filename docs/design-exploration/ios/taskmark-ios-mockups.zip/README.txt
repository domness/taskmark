Taskmark mobile screen concepts — September 2026

Seven individual iPhone images and three overview boards.
Synthetic content; rendered mockups, not a working iOS app.
Source and reproduction: docs/design-exploration/ios in the Taskmark repository.
